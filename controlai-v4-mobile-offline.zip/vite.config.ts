import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';
export default defineConfig({
  base: '/controlai/',
  plugins: [react(), VitePWA({
    registerType: 'autoUpdate',
    includeAssets: ['icons/icon-192.png', 'icons/icon-512.png'],
    manifest: { name: 'ControlAI - Controle Financeiro', short_name: 'ControlAI', description: 'Controle financeiro offline', theme_color: '#2459e0', background_color: '#f6f8fc', display: 'standalone', start_url: '/controlai/', scope: '/controlai/', icons: [{ src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any maskable' }, { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any maskable' }] }
  })]
});
